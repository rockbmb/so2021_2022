#include <sys/types.h>

ssize_t readln1(int fd, char *line, size_t size);